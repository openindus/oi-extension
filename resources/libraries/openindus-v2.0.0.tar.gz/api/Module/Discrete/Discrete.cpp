/**
 * @file Discrete.cpp
 * @brief Discrete
 * @author
 * @copyright (c) [2024] OpenIndus, Inc. All rights reserved.
 * @see https://openindus.com
 */

#include "Discrete.h"

#if (defined(CONFIG_OI_DISCRETE) || defined(CONFIG_OI_DISCRETE_VE))

static const char TAG[] = "Discrete";

const gpio_num_t _doutGpio[] = {
    DISCRETE_PIN_DOUT_1,
    DISCRETE_PIN_DOUT_2,
    DISCRETE_PIN_DOUT_3,
    DISCRETE_PIN_DOUT_4,
    DISCRETE_PIN_DOUT_5,
    DISCRETE_PIN_DOUT_6,
    DISCRETE_PIN_DOUT_7,
    DISCRETE_PIN_DOUT_8
};

const adc_unit_t _doutAdcUnits[] = {
    ADC_UNIT_1, ADC_UNIT_1, ADC_UNIT_1, ADC_UNIT_1,
    ADC_UNIT_1, ADC_UNIT_1, ADC_UNIT_1, ADC_UNIT_1
};

const adc_channel_t _doutAdcChannels[] = {
    ADC_CHANNEL_0, ADC_CHANNEL_1, ADC_CHANNEL_3, ADC_CHANNEL_4,
    ADC_CHANNEL_5, ADC_CHANNEL_6, ADC_CHANNEL_7, ADC_CHANNEL_8
};

const gpio_num_t _dinGpio[] = {
    DISCRETE_PIN_DIN_1,
    DISCRETE_PIN_DIN_2,
    DISCRETE_PIN_DIN_3,
    DISCRETE_PIN_DIN_4,
    DISCRETE_PIN_DIN_5,
    DISCRETE_PIN_DIN_6,
    DISCRETE_PIN_DIN_7,
    DISCRETE_PIN_DIN_8,
    DISCRETE_PIN_DIN_9,
    DISCRETE_PIN_DIN_10
};

const adc_unit_t _ainUnits[] = {
    ADC_UNIT_2, ADC_UNIT_2
};

adc_channel_t _ainChannels[] = {
    ADC_CHANNEL_0, ADC_CHANNEL_1
};

int Discrete::init(void)
{
    int err = 0;
    
    ESP_LOGI(TAG, "Discrete init.");

#if defined(CONFIG_OI_DISCRETE)
    err |= Module::init(TYPE_OI_DISCRETE);
#elif defined(CONFIG_OI_DISCRETE_VE)
    err |= Module::init(TYPE_OI_DISCRETE_VE);
#endif

    err |= DigitalOutputs::init(_doutGpio, _doutAdcUnits, _doutAdcChannels, DISCRETE_NUMBER_OF_DOUT,
                               _adc_handle, _adc2_handle, _adc_cali_handle, _adc2_cali_handle);
    err |= DigitalInputs::init(_dinGpio, DISCRETE_NUMBER_OF_DIN);
    
    err |= AnalogInputsHV::init(ADC_UNIT_1, _ainChannels, DISCRETE_NUMBER_OF_AIN, _adc_handle);

#if defined(CONFIG_MODULE_SLAVE)
    err |= AnalogInputsHVCmdHandler::init();
    err |= DigitalOutputsCmdHandler::init();
    err |= DigitalInputsCmdHandler::init();
#endif

    /* CLI */
    err |= DigitalInputsCLI::init();
    err |= DigitalOutputsCLI::init();

    return err;
}

#endif