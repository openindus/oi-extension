/**
 * @file Module.cpp
 * @brief Module interface
 * @author Kévin Lefeuvre (kevin.lefeuvre@openindus.com)
 * @copyright (c) [2025] OpenIndus, Inc. All rights reserved.
 * @see https://openindus.com
 */

#include "Module.h"
#include "ModulePinout.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"

static const char TAG[] = "Module";

uint16_t Module::_type = 0;
adc_oneshot_unit_handle_t Module::_adc_handle = NULL;
adc_oneshot_unit_handle_t Module::_adc2_handle = NULL;
adc_cali_handle_t Module::_adc_cali_handle = NULL;
adc_cali_handle_t Module::_adc2_cali_handle = NULL;

int Module::init(uint16_t type)
{
    int err = 0;

    /* Board */
    ESP_LOGI(TAG, "Board init.");
    err |= Board::init();

    /* eFuse - Board info */
    uint16_t local_type = getBoardType(); // read it only once to avoid multiple warning
    uint16_t local_variant = getHardwareVariant(); // read it only once to avoid multiple warning
    
    char local_name[16];
    ESP_LOGI(TAG, "Board type       : %u (%s)", local_type, BoardUtils::typeToName(local_type, local_name));
    ESP_LOGI(TAG, "Hardware variant : %u", local_variant);
    ESP_LOGI(TAG, "Serial number    : %d", getSerialNum());
    char str_date[13];
    time_t t = (time_t) getTimestamp();
    struct tm lt;
    localtime_r(&t, &lt);
    strftime(str_date, sizeof(str_date), "(%d/%m/%Y)", &lt);
    ESP_LOGI(TAG, "Board timestamp  : %lli %s", getTimestamp(), str_date);
    char software_version[32];
    getSoftwareVersion(software_version);
    ESP_LOGI(TAG, "Software version : %s", software_version);

    if (local_type != type) {
        // Hack because we cannot differentiate CONFIG_OI_CORE and CONFIG_OI_CORELITE for now...
        if (type == TYPE_OI_CORE && local_type == TYPE_OI_CORELITE) {
            ESP_LOGI(TAG, "OICoreLite type checked");
        } else if (local_type == 0){
            ESP_LOGW(TAG, "Cannot check board type");
            _type = type; // Save type because the one in eFuse is wrong
        } else {
            char name[16];
            char local_name[16];
            ESP_LOGE(TAG, "Incorrect board type detected ! You have program the board as an %s and board is an %s", \
                BoardUtils::typeToName(type, name), BoardUtils::typeToName(local_type, local_name));
            err |= -1; // Do not start the code because we are on wrong board
        }
    }

    /* ADC */
    // Configure ADC oneshot unit 1
    adc_oneshot_unit_init_cfg_t init_config1 = {};
    init_config1.unit_id = ADC_UNIT_1;
    if (adc_oneshot_new_unit(&init_config1, &Module::_adc_handle) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to initialize ADC unit 1");
    }

    // Configure ADC oneshot unit 2
    adc_oneshot_unit_init_cfg_t init_config2 = {};
    init_config2.unit_id = ADC_UNIT_2;
    if (adc_oneshot_new_unit(&init_config2, &Module::_adc2_handle) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to initialize ADC unit 2");
    }

    // Initialize ADC calibration for unit 1
#if ADC_CALI_SCHEME_CURVE_FITTING_SUPPORTED
    adc_cali_curve_fitting_config_t cali_config1 = {
        .unit_id = ADC_UNIT_1,
        .chan = ADC_CHANNEL_0,
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    if (adc_cali_create_scheme_curve_fitting(&cali_config1, &Module::_adc_cali_handle) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to create calibration scheme for ADC unit 1");
    }
#else
    adc_cali_line_fitting_config_t cali_config1 = {
        .unit_id = ADC_UNIT_1,
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    if (adc_cali_create_scheme_line_fitting(&cali_config1, &Module::_adc_cali_handle) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to create calibration scheme for ADC unit 1");
    }
#endif

    // Initialize ADC calibration for unit 2
#if ADC_CALI_SCHEME_CURVE_FITTING_SUPPORTED
    adc_cali_curve_fitting_config_t cali_config2 = {
        .unit_id = ADC_UNIT_2,
        .chan = ADC_CHANNEL_0,
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    if (adc_cali_create_scheme_curve_fitting(&cali_config2, &Module::_adc2_cali_handle) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to create calibration scheme for ADC unit 2");
    }
#else
    adc_cali_line_fitting_config_t cali_config2 = {
        .unit_id = ADC_UNIT_2,
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    if (adc_cali_create_scheme_line_fitting(&cali_config2, &Module::_adc2_cali_handle) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to create calibration scheme for ADC unit 2");
    }
#endif

    /* LED */
    ESP_LOGI(TAG, "LED init.");
    Led::install(MODULE_PIN_LED);
    Led::on(LED_BLUE);

#if defined(CONFIG_MODULE_MASTER) || defined(CONFIG_MODULE_SLAVE)

    /* Bus */
    ESP_LOGI(TAG, "Bus init");

    /* Bus RS/CAN */
    err |= BusRS::begin(MODULE_RS_NUM_PORT, MODULE_PIN_RS_UART_TX, MODULE_PIN_RS_UART_RX);
    err |= BusCAN::begin(MODULE_PIN_CAN_TX, MODULE_PIN_CAN_RX);

#if defined(CONFIG_MODULE_MASTER)
    /* Bus IO */
    BusIO::Config_t config = {
        .adcChannelId = MODULE_OI_ID_ADC_CHANNEL,
        .adcWidthId = MODULE_OI_ID_ADC_WIDTH,
        .gpioNumSync = MODULE_PIN_OI_GPIO,
        .gpioModeSync = GPIO_MODE_INPUT_OUTPUT,
        .gpioNumPower = MODULE_PIN_CMD_MOSFET_ALIM,
        .adcHandle = Module::_adc_handle,
        .adcCaliHandle = NULL,
    };
#elif defined(CONFIG_MODULE_SLAVE)
    /* Bus IO */
    BusIO::Config_t config = {
        .adcChannelId = MODULE_OI_ID_ADC_CHANNEL,
        .adcWidthId = MODULE_OI_ID_ADC_WIDTH,
        .gpioNumSync = MODULE_PIN_OI_GPIO,
        .gpioModeSync = GPIO_MODE_INPUT,
        .gpioNumPower = MODULE_PIN_CMD_MOSFET_ALIM,
        .adcHandle = Module::_adc_handle,
        .adcCaliHandle = NULL,
    };
#endif
    err |= BusIO::init(&config);
#endif

    Bus::init();

    return err;
}