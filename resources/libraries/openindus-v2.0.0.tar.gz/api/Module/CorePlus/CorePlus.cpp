/**
 * @file CorePlus.cpp
 * @brief Module OICore+
 * @author 
 * @copyright (c) [2025] OpenIndus, Inc. All rights reserved.
 * @see https://openindus.com
 */

#include "CorePlus.h"