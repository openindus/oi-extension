/**
 * @file CorePlus.h
 * @brief Module OICore+
 * @author 
 * @copyright (c) [2025] OpenIndus, Inc. All rights reserved.
 * @see https://openindus.com
 */

#pragma once