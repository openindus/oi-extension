/**
 * @file Digipot.cpp
 * @brief Digital potentiometer
 * @author 
 * @copyright (c) [2024] OpenIndus, Inc. All rights reserved.
 * @see https://openindus.com
 */

#include "Digipot.h"