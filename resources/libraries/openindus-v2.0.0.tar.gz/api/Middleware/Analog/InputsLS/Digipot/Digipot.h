/**
 * @file Digipot.h
 * @brief Digital potentiometer
 * @author 
 * @copyright (c) [2024] OpenIndus, Inc. All rights reserved.
 * @see https://openindus.com
 */

#pragma once

class Digipot
{

};