/**
 * Copyright (C) OpenIndus, Inc - All Rights Reserved
 *
 * This file is part of OpenIndus Library.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * 
 * @file BusRS.h
 * @brief this class control the bus
 *
 * For more information on OpenIndus:
 * @see https://openindus.com
 */

#pragma once

#include <string.h>
#include "esp_err.h"
#include "esp_log.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

class BusRS
{
public:

    typedef struct __attribute__((__packed__)) {
        uint8_t sync;
        uint8_t cmd;
        union {
            struct { 
                uint16_t id         : 11;   // 0 --> Broadcast ID
                uint16_t dir        : 1;    // 1 --> Master to Slave | 0 --> Slave to Master
                uint16_t ack        : 1;    // ack needed
                uint16_t error      : 1;    // Error
                uint16_t reserved   : 2;
            };
            uint16_t flags;
        };
        uint16_t length; // data length
        uint8_t checksum;
        uint8_t* data;
    } Frame_t;

    static int begin(uart_port_t port, gpio_num_t tx_num, gpio_num_t rx_num);
    static void end(void);
    static void write(Frame_t* frame, uint32_t timeout=0);
    static int read(Frame_t* frame, uint32_t timeout=portMAX_DELAY);

private:

    static uart_port_t _port;
    static QueueHandle_t _eventQueue;
    static SemaphoreHandle_t _writeMutex;
    static SemaphoreHandle_t _writeReadMutex;

    static uint8_t _calculateChecksum(Frame_t *frame);
    static bool _verifyChecksum(Frame_t *frame);

};
